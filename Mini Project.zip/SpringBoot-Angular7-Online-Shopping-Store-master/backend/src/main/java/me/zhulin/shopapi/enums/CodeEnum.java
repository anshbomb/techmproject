package me.zhulin.shopapi.enums;

/**
 * Created.
 */
public interface CodeEnum {
    Integer getCode();

}
