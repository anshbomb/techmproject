package me.zhulin.shopapi.api;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created.
 */
public class CartControllerTest {

    @Test
    public void getCart() {
    }
}
